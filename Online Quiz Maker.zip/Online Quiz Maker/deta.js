// This file can be extended later for API-based storage
