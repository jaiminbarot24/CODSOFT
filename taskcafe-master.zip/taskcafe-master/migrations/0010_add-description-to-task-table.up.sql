ALTER TABLE task ADD COLUMN description text;
