ALTER TABLE task_label ADD UNIQUE (project_label_id, task_id);
