ALTER TABLE user_account ALTER COLUMN profile_avatar_url SET DEFAULT null;
