ALTER TABLE user_account DROP COLUMN first_name;
