ALTER TABLE label_color ADD COLUMN name TEXT NOT NULL DEFAULT 'needs name';
