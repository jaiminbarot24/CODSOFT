ALTER TABLE user_account ADD COLUMN bio text NOT NULL DEFAULT '';
