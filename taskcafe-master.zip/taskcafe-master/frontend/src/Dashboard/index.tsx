import React from 'react';
import { Redirect } from 'react-router';

const Dashboard: React.FC = () => {
  return <Redirect to="/projects" />;
};

export default Dashboard;
