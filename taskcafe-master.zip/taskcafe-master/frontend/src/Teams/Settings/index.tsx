import React from 'react';

const TeamSettings = () => {
  return <h1>HI!</h1>;
};

export default TeamSettings;
