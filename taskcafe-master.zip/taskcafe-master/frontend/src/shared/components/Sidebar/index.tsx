import React from 'react';

import Container from './Styles';

const Sidebar = () => {
  return <Container />;
};

export default Sidebar;
