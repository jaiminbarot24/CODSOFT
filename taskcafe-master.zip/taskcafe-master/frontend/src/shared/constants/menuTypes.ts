const MenuTypes = {
  LABEL_MANAGER: 1,
  LABEL_EDITOR: 2,
  LIST_ACTIONS: 3,
};

export default MenuTypes;
