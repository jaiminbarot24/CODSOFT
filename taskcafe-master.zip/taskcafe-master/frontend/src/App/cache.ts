import { InMemoryCache } from '@apollo/client';

const cache = new InMemoryCache();

export default cache;
